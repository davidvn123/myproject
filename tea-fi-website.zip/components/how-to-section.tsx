"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Wallet, Droplets, ArrowRightLeft, Coins, Target, Trophy } from "lucide-react"

const steps = [
  {
    icon: Wallet,
    title: "Create Wallet",
    description: "Set up a Web3 wallet like MetaMask or WalletConnect",
    color: "from-primary to-primary/70",
  },
  {
    icon: Droplets,
    title: "Get Test Tokens",
    description: "Use our faucet to get testnet tokens for transactions",
    color: "from-secondary to-secondary/70",
  },
  {
    icon: ArrowRightLeft,
    title: "Start Swapping",
    description: "Try cross-chain swaps between different networks",
    color: "from-primary to-primary/70",
  },
  {
    icon: Coins,
    title: "Stake & Earn",
    description: "Stake your tokens in liquidity pools for rewards",
    color: "from-secondary to-secondary/70",
  },
  {
    icon: Target,
    title: "Complete Missions",
    description: "Finish daily tasks and special challenges",
    color: "from-primary to-primary/70",
  },
  {
    icon: Trophy,
    title: "Claim Rewards",
    description: "Collect your Sugar Cubes and unlock mystery boxes",
    color: "from-secondary to-secondary/70",
  },
]

export function HowToSection() {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            How to Get Started
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-secondary mx-auto rounded-full mb-6" />
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Follow these simple steps to join the Tea-Fi testnet and start earning rewards
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {steps.map((step, index) => {
            const Icon = step.icon
            return (
              <Card
                key={index}
                className="relative overflow-hidden border-2 border-border hover:border-primary/40 transition-all duration-500 hover:scale-105 hover:shadow-xl group"
                style={{
                  animationDelay: `${index * 0.1}s`,
                }}
              >
                {/* Step number */}
                <div className="absolute top-4 right-4 w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold text-sm">
                  {index + 1}
                </div>

                <CardHeader className="pb-4">
                  <div
                    className={`w-16 h-16 rounded-full bg-gradient-to-br ${step.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">{step.title}</CardTitle>
                </CardHeader>

                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">{step.description}</p>
                </CardContent>

                {/* Hover effect overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
              </Card>
            )
          })}
        </div>

        {/* Call to action */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center gap-2 text-sm text-muted-foreground mb-4">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            Ready in just a few minutes
          </div>
          <p className="text-lg text-foreground">{"Join our community and start your DeFi journey today!"}</p>
        </div>
      </div>
    </section>
  )
}
