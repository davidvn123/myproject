"use client"

import { Twitter, MessageCircle, Send, FileText, Globe } from "lucide-react"

export function Footer() {
  const socialLinks = [
    { icon: Globe, label: "Website", href: "https://app.tea-fi.com/?ref=3j47rp" },
    { icon: FileText, label: "Medium", href: "#" },
    { icon: Twitter, label: "Twitter", href: "https://x.com/TeaFi_Official" },
    { icon: MessageCircle, label: "Discord", href: "https://discord.gg/qZ2wkVFX" },
    { icon: Send, label: "Telegram", href: "https://t.me/teaficommunity" },
    { icon: FileText, label: "Whitepaper", href: "#" },
  ]

  return (
    <footer className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-secondary/10">
      {/* Animated glow borders */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent animate-pulse" />

      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-3 gap-12 items-center">
          {/* Logo and description */}
          <div className="text-center lg:text-left">
            <div className="flex items-center justify-center lg:justify-start gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-2xl animate-glow">
                🫖
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Tea-Fi
              </span>
            </div>
            <p className="text-muted-foreground leading-relaxed max-w-md mx-auto lg:mx-0">
              The next generation of decentralized finance. Experience seamless cross-chain swaps, easy gas payments,
              and rewarding testnet participation.
            </p>
          </div>

          {/* Social links */}
          <div className="text-center">
            <h3 className="text-lg font-semibold mb-6 text-foreground">Connect With Us</h3>
            <div className="grid grid-cols-3 gap-4 max-w-xs mx-auto">
              {socialLinks.map((link, index) => {
                const Icon = link.icon
                return (
                  <a
                    key={index}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex flex-col items-center gap-2 p-4 rounded-lg border border-border hover:border-primary/40 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-primary/20"
                    aria-label={link.label}
                  >
                    <Icon className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
                    <span className="text-xs text-muted-foreground group-hover:text-primary transition-colors">
                      {link.label}
                    </span>
                  </a>
                )
              })}
            </div>
          </div>

          {/* Newsletter signup */}
          <div className="text-center lg:text-right">
            <h3 className="text-lg font-semibold mb-6 text-foreground">Stay Updated</h3>
            <p className="text-muted-foreground mb-4 text-sm">
              Get the latest updates on Tea-Fi development and testnet rewards
            </p>
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto lg:mx-0 lg:ml-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-2 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50"
              />
              <button className="px-6 py-2 bg-gradient-to-r from-primary to-secondary text-white rounded-lg font-medium hover:from-primary/90 hover:to-secondary/90 transition-all duration-300 hover:scale-105">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        {/* Bottom section */}
        <div className="border-t border-border mt-12 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-muted-foreground text-sm">© 2024 Tea-Fi. All rights reserved.</p>
            <div className="flex items-center gap-6 text-sm">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Documentation
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Background decoration */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-primary/5 to-transparent pointer-events-none" />
    </footer>
  )
}
