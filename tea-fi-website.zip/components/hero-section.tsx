"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  const [particles, setParticles] = useState<Array<{ id: number; delay: number; size: number }>>([])

  useEffect(() => {
    const particleArray = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      delay: Math.random() * 15,
      size: Math.random() * 4 + 2,
    }))
    setParticles(particleArray)
  }, [])

  return (
    <section
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #d43192 0%, #a02a7a 50%, #6820a7 100%)",
        backgroundColor: "#d43192", // fallback
      }}
    >
      {/* Animated particles */}
      <div className="absolute inset-0">
        {particles.map((particle) => (
          <div
            key={particle.id}
            className="absolute w-2 h-2 bg-white/30 rounded-full animate-particle"
            style={{
              left: `${Math.random() * 100}%`,
              animationDelay: `${particle.delay}s`,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
        <div className="mb-8 flex justify-center">
          <div
            className="w-24 h-24 rounded-2xl backdrop-blur-sm border border-white/20 flex items-center justify-center text-6xl animate-float animate-glow shadow-2xl"
            style={{
              background: "rgba(255, 255, 255, 0.25)",
              backgroundColor: "rgba(255, 255, 255, 0.2)", // fallback
            }}
          >
            🫖
          </div>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-slide-in-up text-balance text-white drop-shadow-lg">
          Tea-Fi – All-in-One DeFi Platform
        </h1>

        <p
          className="text-xl md:text-2xl mb-8 text-white/95 max-w-3xl mx-auto animate-slide-in-up text-pretty drop-shadow-md"
          style={{ animationDelay: "0.2s" }}
        >
          Experience the next generation of decentralized finance with cross-chain swaps, easy gas payments, and
          reward-driven testnet participation.
        </p>

        <Button
          size="lg"
          className="bg-white text-primary hover:bg-white/90 font-bold px-8 py-4 text-lg rounded-xl transition-all duration-300 hover:scale-105 animate-slide-in-up animate-glow shadow-xl"
          style={{ animationDelay: "0.4s" }}
          asChild
        >
          <a href="https://app.tea-fi.com/?ref=3j47rp" target="_blank" rel="noopener noreferrer">
            Join the Testnet Beta
          </a>
        </Button>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/70 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/70 rounded-full mt-2 animate-pulse" />
        </div>
      </div>
    </section>
  )
}
