"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-background/95 backdrop-blur-md border-b border-border" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-lg animate-glow shadow-lg"
              style={{
                background: "linear-gradient(135deg, #d43192 0%, #6820a7 100%)",
                backgroundColor: "#d43192", // fallback
              }}
            >
              🫖
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Tea-Fi
            </span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a href="#tokenomics" className="text-foreground hover:text-primary transition-colors">
              Tokenomics
            </a>
            <a href="#roadmap" className="text-foreground hover:text-primary transition-colors">
              Roadmap
            </a>
            <a href="#testnet" className="text-foreground hover:text-primary transition-colors">
              Testnet
            </a>
            <a href="#faq" className="text-foreground hover:text-primary transition-colors">
              FAQ
            </a>
          </div>

          <Button
            className="text-white font-semibold px-6 py-2 rounded-lg transition-all duration-300 hover:scale-105 animate-glow shadow-lg"
            style={{
              background: "linear-gradient(135deg, #d43192 0%, #6820a7 100%)",
              backgroundColor: "#d43192", // fallback
            }}
            asChild
          >
            <a href="https://app.tea-fi.com/?ref=3j47rp" target="_blank" rel="noopener noreferrer">
              Join Testnet
            </a>
          </Button>
        </div>
      </div>
    </nav>
  )
}
