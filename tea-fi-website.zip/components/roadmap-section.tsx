"use client"

import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, Clock, Zap, Smartphone, Brain, Layers } from "lucide-react"

const roadmapItems = [
  {
    title: "IDO Launch",
    description: "Successfully launched initial DEX offering",
    status: "completed",
    icon: CheckCircle,
    date: "Q2 2024",
  },
  {
    title: "Beta Platform",
    description: "Released beta version with core DeFi features",
    status: "completed",
    icon: CheckCircle,
    date: "Q3 2024",
  },
  {
    title: "TeaParty Airdrop",
    description: "Community airdrop and reward distribution",
    status: "completed",
    icon: CheckCircle,
    date: "Q3 2024",
  },
  {
    title: "Easy-Gas Integration",
    description: "Simplified gas payment system implementation",
    status: "completed",
    icon: CheckCircle,
    date: "Q4 2024",
  },
  {
    title: "Sugar Cubes System",
    description: "Reward tracking and gamification features",
    status: "completed",
    icon: CheckCircle,
    date: "Q4 2024",
  },
  {
    title: "Mainnet Launch",
    description: "Full production release with all features",
    status: "upcoming",
    icon: Zap,
    date: "Q4 2025",
  },
  {
    title: "Cross-Chain Bridges",
    description: "Additional blockchain integrations",
    status: "upcoming",
    icon: Layers,
    date: "Q1 2026",
  },
  {
    title: "Advanced Staking",
    description: "Enhanced staking pools and rewards",
    status: "upcoming",
    icon: Clock,
    date: "Q2 2026",
  },
  {
    title: "AI Copilot",
    description: "AI-powered trading and DeFi assistance",
    status: "upcoming",
    icon: Brain,
    date: "Q3 2026",
  },
  {
    title: "Mobile App",
    description: "Native mobile application release",
    status: "upcoming",
    icon: Smartphone,
    date: "Q4 2026",
  },
]

export function RoadmapSection() {
  return (
    <section id="roadmap" className="py-20 bg-gradient-to-br from-muted/30 to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Roadmap
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-secondary mx-auto rounded-full" />
        </div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-primary to-secondary rounded-full opacity-30" />

          <div className="space-y-8">
            {roadmapItems.map((item, index) => {
              const Icon = item.icon
              const isCompleted = item.status === "completed"

              return (
                <div
                  key={index}
                  className={`flex items-center gap-8 ${index % 2 === 0 ? "flex-row" : "flex-row-reverse"}`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? "text-right" : "text-left"}`}>
                    <Card
                      className={`inline-block max-w-md transition-all duration-300 hover:scale-105 hover:shadow-lg ${
                        isCompleted
                          ? "border-primary/40 hover:shadow-primary/20"
                          : "border-secondary/40 hover:shadow-secondary/20"
                      }`}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-center gap-3 mb-2">
                          <Icon className={`w-5 h-5 ${isCompleted ? "text-primary" : "text-secondary"}`} />
                          <h3 className="font-bold text-lg">{item.title}</h3>
                        </div>
                        <p className="text-muted-foreground mb-2">{item.description}</p>
                        <span
                          className={`text-sm font-semibold px-3 py-1 rounded-full ${
                            isCompleted ? "bg-primary/20 text-primary" : "bg-secondary/20 text-secondary"
                          }`}
                        >
                          {item.date}
                        </span>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Timeline dot */}
                  <div
                    className={`w-4 h-4 rounded-full border-4 ${
                      isCompleted ? "bg-primary border-primary/30" : "bg-secondary border-secondary/30"
                    } animate-pulse`}
                  />

                  <div className="flex-1" />
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
