"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronDown, ChevronUp } from "lucide-react"

const faqs = [
  {
    question: "What are Sugar Cubes?",
    answer:
      "Sugar Cubes are points earned on the Tea-Fi testnet for completing various activities like swaps, staking, and missions. These points are used to calculate your share of rewards and airdrops when we transition to mainnet.",
  },
  {
    question: "How do I get the airdrop?",
    answer:
      "To be eligible for the airdrop, you need to actively participate in the testnet by completing tasks, earning Sugar Cubes, and engaging with the platform. The more Sugar Cubes you accumulate, the larger your potential airdrop allocation.",
  },
  {
    question: "Are there any risks involved?",
    answer:
      "Tea-Fi testnet uses only test tokens with no real monetary value. There are no financial risks involved in testing. However, always use caution and never share your private keys or seed phrases with anyone.",
  },
  {
    question: "Can I convert test tokens to real money?",
    answer:
      "No, test tokens used on the testnet have no real monetary value and cannot be converted to real money. However, the Sugar Cubes you earn will determine your eligibility for real TEA token rewards in the future.",
  },
  {
    question: "What is Easy-Gas and how does it work?",
    answer:
      "Easy-Gas is our innovative gas payment system that simplifies transaction fees. Instead of worrying about having the right tokens for gas fees on different chains, Easy-Gas automatically handles fee payments using your available balance.",
  },
  {
    question: "When will the mainnet launch?",
    answer:
      "The Tea-Fi mainnet is scheduled to launch in Q4 2025. This timeline may be adjusted based on development progress and security audits. All testnet participants will be notified well in advance.",
  },
  {
    question: "How do I track my Sugar Cubes?",
    answer:
      "You can track your Sugar Cubes directly on your Tea-Fi dashboard after connecting your wallet. The dashboard shows your current balance, recent activities, completed missions, and progress toward various milestones.",
  },
  {
    question: "What are Mystery Boxes?",
    answer:
      "Mystery Boxes are special rewards that can contain bonus Sugar Cubes, exclusive NFTs, early access privileges, or other surprises. You can earn Mystery Boxes by completing special missions and achieving certain milestones on the testnet.",
  },
]

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section id="faq" className="py-20 bg-gradient-to-br from-muted/30 to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Frequently Asked Questions
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-secondary mx-auto rounded-full mb-6" />
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Everything you need to know about Tea-Fi testnet and rewards
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <Card
              key={index}
              className="border-2 border-border hover:border-primary/30 transition-all duration-300 overflow-hidden"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full p-6 text-left flex items-center justify-between hover:bg-muted/50 transition-colors"
              >
                <h3 className="text-lg font-semibold text-foreground pr-4">{faq.question}</h3>
                <div className="flex-shrink-0">
                  {openIndex === index ? (
                    <ChevronUp className="w-5 h-5 text-primary" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-muted-foreground" />
                  )}
                </div>
              </button>

              {openIndex === index && (
                <CardContent className="pt-0 pb-6 px-6">
                  <div className="border-t border-border pt-4">
                    <p className="text-muted-foreground leading-relaxed">{faq.answer}</p>
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        {/* Contact section */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-4">{"Still have questions? We're here to help!"}</p>
          <div className="flex flex-wrap justify-center gap-4">
            <a
              href="#"
              className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-colors"
            >
              Join Discord
            </a>
            <a
              href="#"
              className="inline-flex items-center gap-2 px-4 py-2 bg-secondary/10 text-secondary rounded-lg hover:bg-secondary/20 transition-colors"
            >
              Follow Twitter
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
