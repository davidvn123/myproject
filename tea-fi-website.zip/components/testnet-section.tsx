"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Wallet, ArrowRightLeft, Coins, Zap, BarChart3, Gift } from "lucide-react"

const steps = [
  {
    icon: Wallet,
    title: "Connect Wallet",
    description: "Link your Web3 wallet to get started",
  },
  {
    icon: ArrowRightLeft,
    title: "Perform Swaps",
    description: "Try cross-chain swaps and staking features",
  },
  {
    icon: Zap,
    title: "Try Easy-Gas",
    description: "Experience simplified gas payments",
  },
  {
    icon: BarChart3,
    title: "Complete Tasks",
    description: "Finish daily and weekly missions",
  },
  {
    icon: Coins,
    title: "Track Sugar Cubes",
    description: "Monitor your points on the dashboard",
  },
]

export function TestnetSection() {
  return (
    <section id="testnet" className="py-20 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 gradient-purple-pink opacity-10" />

      {/* Floating cubes animation */}
      <div className="absolute inset-0">
        {Array.from({ length: 15 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-4 h-4 bg-primary/20 rounded animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 6}s`,
              animationDuration: `${4 + Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Join the Testnet
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-secondary mx-auto rounded-full mb-6" />
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Participate in our beta testing and earn Sugar Cubes for exclusive rewards and airdrops
          </p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 mb-16">
          {steps.map((step, index) => {
            const Icon = step.icon
            return (
              <Card
                key={index}
                className="text-center border-2 border-primary/20 hover:border-primary/40 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-primary/20"
              >
                <CardHeader>
                  <div className="w-16 h-16 mx-auto bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mb-4 animate-glow">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-lg">{step.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm">{step.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Rewards Section */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <Card className="border-2 border-secondary/20 hover:border-secondary/40 transition-all duration-300 hover:shadow-lg hover:shadow-secondary/20">
            <CardHeader>
              <CardTitle className="text-2xl text-secondary flex items-center gap-3">
                <Gift className="w-8 h-8" />
                Testnet Rewards
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg">
                <h4 className="font-bold text-primary mb-2">Sugar Cubes System</h4>
                <p className="text-sm text-muted-foreground">
                  Earn points for every action you take on the testnet. These points determine your share of the final
                  airdrop.
                </p>
              </div>
              <div className="p-4 bg-gradient-to-r from-secondary/10 to-primary/10 rounded-lg">
                <h4 className="font-bold text-secondary mb-2">Mystery Boxes</h4>
                <p className="text-sm text-muted-foreground">
                  Complete special missions to unlock mystery boxes containing bonus rewards and exclusive NFTs.
                </p>
              </div>
              <div className="p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg">
                <h4 className="font-bold text-primary mb-2">Early Access</h4>
                <p className="text-sm text-muted-foreground">
                  Active testnet participants get priority access to new features and exclusive community events.
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="text-center">
            <div className="w-32 h-32 mx-auto mb-8 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center animate-float animate-glow">
              <Gift className="w-16 h-16 text-white" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Ready to Start?</h3>
            <p className="text-muted-foreground mb-6">Join thousands of users already testing the future of DeFi</p>
            <Button
              size="lg"
              className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 text-white font-bold px-8 py-4 text-lg rounded-xl transition-all duration-300 hover:scale-105 animate-glow"
              asChild
            >
              <a href="https://app.tea-fi.com/?ref=3j47rp" target="_blank" rel="noopener noreferrer">
                Launch Testnet App
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
