import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { TokenomicsSection } from "@/components/tokenomics-section"
import { RoadmapSection } from "@/components/roadmap-section"
import { TestnetSection } from "@/components/testnet-section"
import { HowToSection } from "@/components/how-to-section"
import { FAQSection } from "@/components/faq-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <HeroSection />
        <TokenomicsSection />
        <RoadmapSection />
        <TestnetSection />
        <HowToSection />
        <FAQSection />
      </main>
      <Footer />
    </div>
  )
}
